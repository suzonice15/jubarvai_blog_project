
<!--<footer class="navbar-fixed-bottom " style="width: 100%;background: none;" id="SidebarCardMenu">-->
<footer class="navbar-fixed-bottom area-mobile-off" style="width: 100%;background: none;" >
    <a href="http://www.ajibto.com/resistration-information">
        <!--Apps button start-->
        <div  style="height: auto;width: 80px;background: #fff ;position: absolute;z-index: 9999;bottom: 450px;right: 0;border-radius: 5px 0 0 5px;border: 1px solid #1D70BA;" class="cart_anchor">



                 <span id="CartDetailsTotal"  style="padding: 8px 0;width:100%;display: inline-block;color:#000;font-size:14px;font-weight:bold;text-align:center">
                        11   Tk.
                    </span>

            <span  style="width:100%;display: inline-block; background: #00255f ; color: #fff;font-weight:bold;padding:2px;text-align:center;border-radius: 0 0 0 5px;">
                        <i class="fa fa-shopping-cart " title="My Cart" style="    font-size: 30px;"> </i>
                        <span id="totalCartItems2">
                            0 Items
                        </span>
                    </span>


        </div>
    </a>

    <!--Apps button end-->
</footer>





<footer class="navbar-default" style="background: #fff">
    <div class="container" style="padding-top: 25px;  padding-bottom: 25px;">

        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" >
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-zero" >
                <h4 style="font-weight: bold;">Payment System</h4>
                <img style="cursor: pointer"  src="http://www.ajibto.com/image/manufacturer_logo/pay.jpg" alt="ajibto" title="ajibto">

                <div class="social-container">
                    <ul class="social-icons">
                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>


        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 padding-zero" >


            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" >
                <h4 style="font-weight: bold;">Informatica</h4>
                <ul >
                    <li class="fotter-menu-padding"><a href="http://www.ajibto.com/about-us" title="Login" class="font-color1">About Us</a></li>
                    <li class="fotter-menu-padding"><a href="http://www.ajibto.com/delivery-payment" title="Login" class="font-color1">Delivery & Payment</a></li>
                    <li class="fotter-menu-padding"><a href="http://www.ajibto.com/replace-refund" title="Login" class="font-color1">Replace & Refund</a></li>
                </ul>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" >
                <h4 style="font-weight: bold;">  Top Category </h4>
                <ul >
                    <li class="fotter-menu-padding"><a href="http://www.ajibto.com/category/গৃহস্থালী-পণ্য/2" title="গৃহস্থালী পণ্য" class="font-color1">গৃহস্থালী পণ্য</a></li>
                    <li class="fotter-menu-padding"><a href="http://www.ajibto.com/category/স্বাস্থ্য-সুরক্ষা--পণ্য/3" title="স্বাস্থ্য সুরক্ষা  পণ্য" class="font-color1">স্বাস্থ্য সুরক্ষা  পণ্য</a></li>
                    <li class="fotter-menu-padding"><a href="http://www.ajibto.com/category/ইলেকট্রনিক্স-পণ্য-/4" title="ইলেকট্রনিক্স পণ্য " class="font-color1">ইলেকট্রনিক্স পণ্য </a></li>
                    <li class="fotter-menu-padding"><a href="http://www.ajibto.com/category/ছেলেদের-শপিং/5" title="ছেলেদের শপিং" class="font-color1">ছেলেদের শপিং</a></li>

                </ul>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 padding-zero" >
                <h4 style="font-weight: bold;">Office Address Address </h4>

                <address style="color: #666;font-weight: normal; font-size: 14px;margin-bottom: 10px;">

                    236/2 West Nakhalpara <br>
                    Tejgoan, Dhaka-1215 <br><br>
                    <strong>Help Line: 01725-990884</strong>
                </address>


                <br>
                <br>
            </div>

        </div>





    </div>
    </div>
</footer>

<footer class="navbar-default" style="background: #F8F8F8">
    <div class="container" style="padding-top: 10px;">



        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 footer-seo-box">


            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-zero" >
                <p class="text-center" style="margin: 20px 0;font-weight: bold;">Copyright © 2019 | ajibto.com </p>
            </div>

        </div>
    </div>
</footer>






<!--<script src="front_asset/js/vendor/jquery-1.11.3.min.js"></script>-->
<script async  type="text/javascript" src="{{ asset('assets/font_end/')}}/js/jquery.min.js"></script>
<script async  type="text/javascript" src="{{ asset('assets/font_end/')}}/js/bootstrap.min.js"></script>
<script async  type="text/javascript" src="{{ asset('assets/font_end/')}}/js/stellarnav.js"></script>
<script async  type="text/javascript" src="{{ asset('assets/font_end/')}}/js/owl.carousel.min.js"></script>
<script async type="text/javascript" src="https://sohojbuy.com/assets/font_end/dist/xzoom.min.js"></script>
<script async type="text/javascript" > var base_url ="{{url('/')}}";</script>
<script async  type="text/javascript" src="{{ asset('assets/font_end/')}}/js/custom.js"></script>



</body>

</html>
<style>
    .alert-box-arrow{
        width: 0;
        height: 0;
        border-left: 12px solid transparent;
        border-right: 12px solid transparent;
        border-bottom: 15px solid #F6F6F6;
        margin-top: -15px;
        position: absolute;
    }
</style>

